package com.hs.main;

import com.hs.service.BSTtoSkewed;
import com.hs.service.Node;

public class Driver {

	public static void main(String[] args) {
		BSTtoSkewed tree = new BSTtoSkewed();
		BSTtoSkewed.node = new Node(50);
		tree.node.left = new Node(30);
		tree.node.right = new Node(60);
		tree.node.left.left = new Node(10);
		tree.node.right.left= new Node(55);
		int order = 0;
		tree.fltBst(node, order);
        tree.traverseRightSkewed(HNode);

	}

}
