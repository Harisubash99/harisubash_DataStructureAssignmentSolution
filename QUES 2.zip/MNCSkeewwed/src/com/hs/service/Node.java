package com.hs.service;

public class Node {
       int data;
       public Node left;
	public Node right;
       public Node (int d){
    	   data = d;
    	   left = right = null;
       }

}
