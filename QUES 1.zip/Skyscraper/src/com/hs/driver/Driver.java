package com.hs.driver;

import com.hs.service.floorDayOrganize;

public class Driver {

	public static void main(String[] args) {
		floorDayOrganize fc = new floorDayOrganize();
		fc.getNoofFloors();

	}

}
