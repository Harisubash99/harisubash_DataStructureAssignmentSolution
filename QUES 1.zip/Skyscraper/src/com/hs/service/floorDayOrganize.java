package com.hs.service;

import java.util.Scanner;

public class floorDayOrganize {

	public void getNoofFloors() {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int getF = sc.nextInt();
		System.out.println("Enter the number of floors : ");
		int x[] = new int [getF+1];
		for (int i = 0; i<getF+1; i++) {
			System.out.println("Enter the size of floors " +i );
			int FSize = sc.nextInt();
			x[i]=FSize;
		}
		int j = getF;
		boolean flag;
		System.out.println("The order of construction is as follows");
		for (int i =0; i<=getF; i++) {
			flag = false;
			System.out.println("Day:"+i );
			while (j>=1 && x[j]<=i) {
			flag = true;
			System.out.print(j+" ");
			j--;
			}
			if (flag == true) {
				System.out.println();
			}
			
		}
		
		
		
	}
	}

	


