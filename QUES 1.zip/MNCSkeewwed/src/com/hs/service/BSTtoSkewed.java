package com.hs.service;
public class BSTtoSkewed {
	public static Node node;
	static Node prevNode = null;
	static Node HNode = null;
	static void fltBst(Node root, int order) {
		if(root == null) {
			return;
		}
		if(order >0) {
			fltBst(root.right,order);
			
		}
		else {
			fltBst(root.left , order);
		}
		Node rightNode = root.right;
		Node leftNode = root.left;
		if(HNode == null) {
			HNode = root;
			root.left = null;
			prevNode = root;
		}
		else {
			prevNode.right = root;
			root.left = null;
			prevNode = root;
		}
		if (order > 0) {
			fltBst(leftNode,order);
		}
		else {
			fltBst(rightNode,order);
		}
	   }
		static void traverseRightSkewed (Node root){
			if (root = null) {
				return;
			}
			System.out.print(root.data + " ");
	        traverseRightSkewed(root.right);
		
		  	
	}
}


